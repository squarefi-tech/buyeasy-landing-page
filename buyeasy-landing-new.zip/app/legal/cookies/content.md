---
title: "Cookie Policy"
order: 3
group: "Core Agreements"
lastUpdated: "2026-02-27"
---

# COOKIE POLICY

**Effective Date:** February 27, 2026

This Cookie Policy explains how BuyEasy Technologies Limited ("BUYEASY", "we", "us", or "our") uses cookies and similar tracking technologies on our website (www.buyeasy.app) and services.

---

## 1. WHAT ARE COOKIES?

Cookies are small text files stored on your device (computer, tablet, or mobile) when you visit a website. They help websites remember your preferences, improve functionality, and analyze usage patterns.

### Types of Cookies

**Session Cookies:** Temporary cookies that expire when you close your browser.

**Persistent Cookies:** Cookies that remain on your device for a set period or until you delete them.

**First-Party Cookies:** Set by BUYEASY directly.

**Third-Party Cookies:** Set by external services we use (analytics, advertising, etc.).

---

## 2. WHY WE USE COOKIES

We use cookies to:
- Enable essential website functionality
- Remember your preferences and settings
- Authenticate and secure your Account
- Analyze website traffic and usage patterns
- Improve user experience and performance
- Deliver personalized content and advertising
- Comply with legal and regulatory requirements

---

## 3. TYPES OF COOKIES WE USE

### 3.1 Strictly Necessary Cookies

These cookies are essential for the website to function and cannot be disabled.

| Cookie Name | Purpose | Duration | Type |
|-------------|---------|----------|------|
| `buyeasy_session` | Maintains your login session and authentication state | Session | First-party |
| `buyeasy_csrf` | Protects against cross-site request forgery attacks | Session | First-party |
| `buyeasy_consent` | Stores your cookie consent preferences | 1 year | First-party |
| `buyeasy_locale` | Remembers your language and region preferences | 1 year | First-party |

### 3.2 Performance and Analytics Cookies

These cookies help us understand how visitors use our website.

| Cookie Name | Purpose | Duration | Type |
|-------------|---------|----------|------|
| `_ga` | Google Analytics — tracks unique visitors | 2 years | Third-party |
| `_ga_*` | Google Analytics — stores session state | 2 years | Third-party |
| `_gid` | Google Analytics — distinguishes users | 24 hours | Third-party |
| `_gat` | Google Analytics — throttles request rate | 1 minute | Third-party |
| `buyeasy_analytics` | Internal analytics and usage tracking | 1 year | First-party |

### 3.3 Functional Cookies

These cookies enable enhanced functionality and personalization.

| Cookie Name | Purpose | Duration | Type |
|-------------|---------|----------|------|
| `buyeasy_dashboard_prefs` | Stores dashboard layout and display preferences | 1 year | First-party |
| `buyeasy_currency_pref` | Remembers your preferred currency display | 1 year | First-party |
| `buyeasy_timezone` | Stores your timezone for accurate transaction timestamps | 1 year | First-party |

### 3.4 Marketing and Advertising Cookies

These cookies are used to deliver relevant advertisements (requires your consent).

| Cookie Name | Purpose | Duration | Type |
|-------------|---------|----------|------|
| `_fbp` | Facebook Pixel — tracks conversions and retargeting | 3 months | Third-party |
| `_gcl_au` | Google Ads — measures ad performance | 3 months | Third-party |
| `buyeasy_campaign` | Tracks marketing campaign attribution | 30 days | First-party |

---

## 4. THIRD-PARTY COOKIES

We use the following third-party services that may set cookies:

### 4.1 Google Analytics

**Purpose:** Website traffic analysis and user behavior insights  
**Provider:** Google LLC  
**Privacy Policy:** https://policies.google.com/privacy  
**Opt-out:** https://tools.google.com/dlpage/gaoptout

### 4.2 Google Ads

**Purpose:** Advertising and conversion tracking  
**Provider:** Google LLC  
**Privacy Policy:** https://policies.google.com/privacy  
**Opt-out:** https://adssettings.google.com

### 4.3 Facebook Pixel

**Purpose:** Ad targeting and conversion measurement  
**Provider:** Meta Platforms, Inc.  
**Privacy Policy:** https://www.facebook.com/privacy/policy  
**Opt-out:** https://www.facebook.com/settings?tab=ads

### 4.4 Calendly

**Purpose:** Meeting scheduling functionality  
**Provider:** Calendly LLC  
**Privacy Policy:** https://calendly.com/privacy

---

## 5. HOW TO MANAGE COOKIES

### 5.1 Cookie Consent Manager

When you first visit our website, you will see a cookie consent banner. You can:
- Accept all cookies
- Accept only necessary cookies
- Customize your preferences

To change your preferences later, click the "Cookie Settings" link in the footer.

### 5.2 Browser Settings

You can control cookies through your browser settings:

**Chrome:**
1. Settings → Privacy and security → Cookies and other site data
2. Choose your preferred option

**Firefox:**
1. Settings → Privacy & Security → Cookies and Site Data
2. Choose your preferred option

**Safari:**
1. Preferences → Privacy → Cookies and website data
2. Choose your preferred option

**Edge:**
1. Settings → Cookies and site permissions → Cookies and site data
2. Choose your preferred option

### 5.3 Mobile Devices

**iOS:**
Settings → Safari → Block All Cookies

**Android:**
Chrome app → Settings → Site settings → Cookies

### 5.4 Opt-Out Tools

You can opt out of targeted advertising through:
- **Digital Advertising Alliance:** http://optout.aboutads.info
- **Network Advertising Initiative:** http://optout.networkadvertising.org
- **European Interactive Digital Advertising Alliance:** http://www.youronlinechoices.eu

---

## 6. IMPACT OF DISABLING COOKIES

### 6.1 Necessary Cookies

If you disable necessary cookies:
- You will not be able to log in to your Account
- Essential functionality will not work
- Security features may be compromised

### 6.2 Performance Cookies

If you disable performance cookies:
- We cannot improve the website based on usage data
- You may still experience technical issues that could have been prevented

### 6.3 Functional Cookies

If you disable functional cookies:
- Your preferences will not be saved
- You may need to re-enter information on each visit
- Personalization features will not work

### 6.4 Marketing Cookies

If you disable marketing cookies:
- You will still see advertisements, but they will not be personalized
- We cannot measure the effectiveness of our marketing campaigns

---

## 7. OTHER TRACKING TECHNOLOGIES

In addition to cookies, we may use:

### 7.1 Web Beacons (Pixels)

Small transparent images embedded in emails or web pages to track:
- Email open rates
- Link clicks
- Page views

### 7.2 Local Storage

Browser storage mechanisms to:
- Cache data for faster performance
- Store user preferences
- Enable offline functionality

### 7.3 Device Fingerprinting

Technical information about your device to:
- Detect fraud
- Prevent unauthorized access
- Enhance security

---

## 8. DO NOT TRACK SIGNALS

Some browsers offer "Do Not Track" (DNT) signals. Currently, there is no industry standard for responding to DNT signals. We do not alter our data collection practices in response to DNT signals, but you can manage cookies through the methods described in Section 5.

---

## 9. UPDATES TO THIS POLICY

We may update this Cookie Policy from time to time to reflect:
- Changes in our cookie usage
- New technologies or services
- Legal or regulatory requirements

We will notify you of material changes by:
- Posting the updated policy on our website
- Displaying a notice on the cookie consent banner
- Sending email notification (for significant changes)

Your continued use of our website after changes take effect constitutes acceptance of the updated policy.

---

## 10. CONTACT US

If you have questions about our use of cookies or this Cookie Policy:

**Data Protection Officer:**  
Email: privacy@buyeasy.app  
Address: 2 Robert Speck Pkwy, Suite 750, Mississauga, ON L4Z 1H8, Canada

**General Support:**  
Email: info@buyeasy.app  
Website: www.buyeasy.app  
Phone: +1 343 883 3504

**Company Information:**  
Company Name: BuyEasy Technologies Limited  
Registration Number: 1500317-2  
Jurisdiction: Canada

---

## 11. COOKIE CONSENT RECORD

By using our website, you acknowledge that:
- You have read and understood this Cookie Policy
- You consent to our use of cookies as described
- You can withdraw or modify your consent at any time through cookie settings

---

**Last Updated:** February 27, 2026
