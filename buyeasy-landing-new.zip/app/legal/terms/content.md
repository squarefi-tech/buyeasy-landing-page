---
title: "Terms of Service"
order: 1
group: "Core Agreements"
lastUpdated: "2026-02-27"
---

# TERMS OF SERVICE

**Effective Date:** February 27, 2026

These Terms of Service ("Terms") constitute a legally binding agreement between you ("User", "you", or "your") and BuyEasy Technologies Limited ("BUYEASY", "Company", "we", "us", or "our"), governing your access to and use of BUYEASY's financial services.

By creating an account or using our Services, you acknowledge that you have read, understood, and agree to be bound by these Terms.

---

## 1. DEFINITIONS

**"Account"** means the multi-currency account(s) opened by the User with BUYEASY to access the Services.

**"Company"** means BuyEasy Technologies Limited, a financial services provider registered in Canada under registration number 1500317-2.

**"Services"** means all financial services provided by BUYEASY, including but not limited to:
- Foreign exchange (FX) transactions
- Multi-currency account management
- International payment processing
- Cross-border money remittance
- Related financial services as described on our website

**"User"** means any individual or legal entity that registers for, accesses, or uses the Services.

---

## 2. DESCRIPTION OF SERVICES

### 2.1 Foreign Exchange

BUYEASY provides foreign exchange services enabling Users to convert funds between 30+ supported currency pairs at competitive market rates. All FX transactions are subject to:
- Real-time rate quotations
- Transparent fee disclosure
- Settlement in accordance with market standards
- Regulatory compliance requirements

### 2.2 Multi-Currency Accounts

Users may open and maintain multi-currency accounts in USD, EUR, GBP, CAD, and other supported currencies. Account features include:
- Access to SWIFT, SEPA, ACH, CHAPS, and Faster Payments networks
- Real-time balance monitoring
- Transaction history and reporting
- API access (for eligible business accounts)

### 2.3 Payment Processing

BUYEASY facilitates domestic and international payment processing, enabling Users to:
- Send and receive payments across borders
- Pay suppliers, partners, and employees in local currencies
- Process bulk payments
- Track payment status in real-time

### 2.4 International Money Transfers

Users may initiate cross-border money transfers to 180+ countries through our remittance services, subject to:
- Compliance with local regulations
- AML/KYC verification requirements
- Transfer limits and processing times as disclosed at the time of transaction

---

## 3. REGISTRATION AND ACCOUNT REQUIREMENTS

### 3.1 Eligibility

To use the Services, you must:
- Be at least 18 years of age (or the age of majority in your jurisdiction)
- Have the legal capacity to enter into binding contracts
- Not be located in a jurisdiction where the Services are prohibited
- Not be listed on any sanctions list or subject to economic sanctions

### 3.2 Account Registration

To open an Account, you must:
- Provide accurate, complete, and current information
- Complete our Know Your Customer (KYC) verification process
- Submit all required documentation (identity verification, proof of address, business documentation if applicable)
- Agree to these Terms and our Privacy Policy

### 3.3 KYC and AML Compliance

BUYEASY is required to comply with Anti-Money Laundering (AML) and Know Your Customer (KYC) regulations. You agree to:
- Provide all requested documentation and information
- Update your information promptly when changes occur
- Cooperate with additional verification requests
- Acknowledge that we may refuse service or suspend your Account if verification cannot be completed

### 3.4 Account Security

You are responsible for:
- Maintaining the confidentiality of your login credentials
- All activities that occur under your Account
- Notifying us immediately of any unauthorized access or security breach
- Using strong passwords and enabling two-factor authentication where available

---

## 4. USE OF SERVICES

### 4.1 Permitted Use

You may use the Services only for lawful purposes and in accordance with these Terms. You agree not to use the Services:
- In any way that violates applicable laws or regulations
- For fraudulent, illegal, or unauthorized purposes
- To engage in money laundering, terrorist financing, or other financial crimes
- To process payments related to prohibited activities (see Section 4.2)
- To circumvent any sanctions or export control laws

### 4.2 Prohibited Activities

The following activities are strictly prohibited:
- Transactions involving illegal goods or services
- Gambling or gaming services (unless properly licensed)
- Adult content or services
- Weapons, explosives, or controlled substances
- Counterfeit goods or intellectual property infringement
- Pyramid schemes, multi-level marketing, or similar arrangements
- Any activity that violates our Acceptable Use Policy

### 4.3 Transaction Limits

BUYEASY may impose transaction limits based on:
- Your Account type and verification level
- Regulatory requirements
- Risk management considerations
- Jurisdictional restrictions

Current limits are available in your Account dashboard or upon request.

---

## 5. FEES AND CHARGES

### 5.1 Fee Structure

BUYEASY charges fees for the Services, including but not limited to:
- Foreign exchange spreads or commissions
- Account maintenance fees (if applicable)
- Payment processing fees
- Wire transfer fees
- Currency conversion fees

### 5.2 Fee Disclosure

All applicable fees will be disclosed to you:
- Before you complete a transaction
- In your Account dashboard
- In transaction confirmations
- Upon request to our support team

### 5.3 Fee Changes

We reserve the right to modify our fee structure with 30 days' prior notice. Continued use of the Services after fee changes constitutes acceptance of the new fees.

### 5.4 Third-Party Fees

You are responsible for any fees charged by:
- Your bank or financial institution
- Intermediary banks in the payment chain
- Currency conversion fees imposed by third parties
- Local taxes or duties

---

## 6. FUNDS AND SETTLEMENT

### 6.1 Segregated Accounts

Client funds are held in segregated accounts with tier-1 banking partners, separate from BUYEASY's operational funds.

### 6.2 Settlement Times

Settlement times vary based on:
- Payment method and network (SWIFT, SEPA, ACH, etc.)
- Currency pair and destination country
- Verification and compliance requirements
- Banking hours and holidays

Estimated settlement times are provided at the time of transaction.

### 6.3 Failed Transactions

If a transaction fails due to insufficient funds, incorrect details, or compliance issues:
- You will be notified promptly
- Funds will be returned to your Account (minus any non-refundable fees)
- We may request additional information or documentation

---

## 7. COMPLIANCE AND REPORTING

### 7.1 Regulatory Obligations

BUYEASY is subject to regulatory oversight in Canada and complies with:
- Anti-Money Laundering (AML) regulations
- Counter-Terrorist Financing (CTF) requirements
- Know Your Customer (KYC) standards
- Data protection and privacy laws
- Financial services regulations

### 7.2 Transaction Monitoring

We monitor transactions for suspicious activity and may:
- Request additional information about transactions
- Delay or refuse transactions that raise compliance concerns
- Report suspicious activity to relevant authorities
- Suspend or terminate Accounts involved in prohibited activities

### 7.3 Reporting to Authorities

We may disclose your information to regulatory authorities, law enforcement, or other government agencies as required by law or in response to valid legal requests.

---

## 8. SUSPENSION AND TERMINATION

### 8.1 Suspension by BUYEASY

We may suspend your Account immediately if:
- We suspect fraudulent, illegal, or unauthorized activity
- You breach these Terms
- We are required to do so by law or regulatory authority
- Your Account poses a risk to BUYEASY or other Users
- You fail to complete KYC verification

### 8.2 Termination by BUYEASY

We may terminate your Account with 30 days' notice, or immediately if:
- You materially breach these Terms
- Your Account remains inactive for an extended period
- We cease offering Services in your jurisdiction
- We are required to do so by law or regulation

### 8.3 Termination by User

You may close your Account at any time by:
- Contacting our support team
- Following the account closure process
- Withdrawing all remaining funds

### 8.4 Effect of Termination

Upon termination:
- You must withdraw all funds from your Account
- Outstanding obligations remain enforceable
- We may retain records as required by law
- Sections that by their nature should survive will continue to apply

---

## 9. LIABILITY AND DISCLAIMERS

### 9.1 Service Availability

We strive to provide uninterrupted Services but do not guarantee:
- Continuous, error-free, or secure access
- Absence of delays, interruptions, or technical issues
- Availability during maintenance, upgrades, or force majeure events

### 9.2 Limitation of Liability

To the maximum extent permitted by law, BUYEASY shall not be liable for:
- Indirect, incidental, special, consequential, or punitive damages
- Loss of profits, revenue, data, or business opportunities
- Damages resulting from third-party actions or services
- Delays or failures due to circumstances beyond our reasonable control

Our total liability to you shall not exceed the fees paid by you in the 12 months preceding the claim.

### 9.3 Third-Party Services

We may integrate with third-party banking partners, payment networks, and service providers. We are not responsible for:
- Actions or omissions of third parties
- Delays or failures in third-party systems
- Third-party fees or charges
- Third-party terms and conditions

### 9.4 User Responsibility

You are solely responsible for:
- Accuracy of payment instructions and recipient details
- Compliance with tax obligations
- Maintaining adequate funds for transactions
- Understanding the risks of international payments and currency fluctuations

---

## 10. INTELLECTUAL PROPERTY

### 10.1 BUYEASY Property

All content, trademarks, logos, software, and materials on our website and platform are the property of BUYEASY or our licensors. You may not:
- Copy, modify, or distribute our content without permission
- Use our trademarks or branding without authorization
- Reverse engineer or decompile our software
- Create derivative works based on our Services

### 10.2 User License

We grant you a limited, non-exclusive, non-transferable license to access and use the Services for their intended purpose, subject to these Terms.

---

## 11. PRIVACY AND DATA PROTECTION

Your use of the Services is subject to our Privacy Policy, which describes how we collect, use, and protect your personal information. By using the Services, you consent to our data practices as described in the Privacy Policy.

---

## 12. AMENDMENTS

We may modify these Terms at any time by:
- Posting updated Terms on our website
- Providing notice via email or Account notification
- Providing at least 30 days' notice for material changes

Continued use of the Services after changes take effect constitutes acceptance of the modified Terms.

---

## 13. GOVERNING LAW AND DISPUTE RESOLUTION

### 13.1 Governing Law

These Terms are governed by the laws of Canada, without regard to conflict of law principles.

### 13.2 Dispute Resolution

Any disputes arising from these Terms or the Services shall be resolved through:
1. **Negotiation:** Parties agree to attempt good-faith negotiation for 30 days
2. **Mediation:** If negotiation fails, non-binding mediation in Canada
3. **Arbitration or Litigation:** As a final resort, binding arbitration or litigation in the courts of Canada

### 13.3 Class Action Waiver

You agree to resolve disputes individually and waive any right to participate in class actions or collective proceedings.

---

## 14. MISCELLANEOUS

### 14.1 Entire Agreement

These Terms, together with our Privacy Policy and Cookie Policy, constitute the entire agreement between you and BUYEASY regarding the Services.

### 14.2 Severability

If any provision of these Terms is found invalid or unenforceable, the remaining provisions shall continue in full force and effect.

### 14.3 Waiver

Our failure to enforce any right or provision of these Terms shall not constitute a waiver of such right or provision.

### 14.4 Assignment

You may not assign or transfer your rights or obligations under these Terms without our prior written consent. We may assign our rights and obligations without restriction.

### 14.5 Force Majeure

We shall not be liable for any delay or failure to perform due to circumstances beyond our reasonable control, including but not limited to acts of God, war, terrorism, pandemics, government actions, or technical failures.

---

## 15. CONTACT INFORMATION

For questions, concerns, or support regarding these Terms or the Services:

**General Support:**  
Email: info@buyeasy.app  
Website: www.buyeasy.app  
Phone: +1 343 883 3504

**Legal Inquiries:**  
Email: legal@buyeasy.app  
Address: 2 Robert Speck Pkwy, Suite 750, Mississauga, ON L4Z 1H8, Canada

**Regulatory Information:**  
Company Name: BuyEasy Technologies Limited  
Registration Number: 1500317-2  
Jurisdiction: Canada

---

**Last Updated:** February 27, 2026
