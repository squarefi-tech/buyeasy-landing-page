import fs from 'fs'
import path from 'path'
import matter from 'gray-matter'
import ReactMarkdown from 'react-markdown'
import Link from 'next/link'

export default function TermsPage() {
  const filePath = path.join(process.cwd(), 'app/legal/terms/content.md')
  const fileContent = fs.readFileSync(filePath, 'utf8')
  const { data, content } = matter(fileContent)

  return (
    <div className="min-h-screen bg-white">
      <nav className="border-b border-gray-200 bg-white">
        <div className="max-w-4xl mx-auto px-6 py-4">
          <Link href="/" className="text-xl font-bold text-gray-900 hover:opacity-75 transition-opacity">
            ← BUYEASY
          </Link>
        </div>
      </nav>
      
      <main className="max-w-4xl mx-auto px-6 py-12">
        <article className="prose prose-gray max-w-none">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">{data.title}</h1>
          {data.lastUpdated && (
            <p className="text-sm text-gray-500 mb-8">Last updated: {data.lastUpdated}</p>
          )}
          <ReactMarkdown>{content}</ReactMarkdown>
        </article>
      </main>
    </div>
  )
}
